#DBScan

dataStore$review_scores_Goodrating <- ifelse(dataStore$review_scores_rating >= 95, 1, 0)
dataStore$review_scores_Goodrating <- factor(dataStore$review_scores_Goodrating)
dataStore$review_scores_Goodrating

#temp <- c("review_scores_Goodrating", "review_scores_accuracy","review_scores_cleanliness","review_scores_checkin","review_scores_communication","review_scores_location","review_scores_value")
#temp <- c("review_scores_cleanliness", "review_scores_accuracy","review_scores_location","review_scores_checkin", "price","accommodates")

temp <- c("price","accommodates","review_scores_Goodrating","availability_365")
dbSubset1 <- dataStore[temp]
#removing all NA from data frame
dbSubset1<-dbSubset1[complete.cases(dbSubset1),]

#dbSubset1<-as.numeric(dbSubset1)
#dbSubset1 <- as.matrix(dbSubset1)

dbSubset1<-matrix(as.numeric(unlist(dbSubset1)),nrow=nrow(dbSubset1))


#dbSubset1[,'price']<-as.factor(dbSubset1[,'price'])

dbscan::kNNdistplot(dbSubset1)
abline(h=10, col="red")

#Run 1
db <- dbscan(dbSubset1, eps=.25, minPts=50)
db

#Run 2
db <- dbscan(dbSubset1, eps=.25, minPts=100)
db

#Run 3
db <- dbscan(dbSubset1, eps=20, minPts=50)
db

#Run 4
db <- dbscan(dbSubset1, eps=20, minPts=25)
db

plot(dbSubset1, col=db$cluster+1L)
hullplot(dbSubset1, db)
