
##################Heirarchical Clustering ###################

setwd("/Users/nik/Documents/Nik/MIM/INST737/Project/Clustering/kMeans")
listingH <- read.csv("listing_latest.csv", header = TRUE)


#subset data as per Research Question1
df <- listingH[ , c("accommodates", "price", "review_scores_rating")]
head(df)
df <- na.omit(df)

#standardize variables
listQ1 <- scale(df) 

#Small sample size
set.seed(75) 
listing_idx <- sample(seq_len(nrow(listQ1)), size=floor(nrow(listQ1)))
subListQ1 <- listQ1[listing_idx,]

idx <- sample(1:dim(subListQ1)[1], 50)
listingSampl <- subListQ1[idx,]
listingSampl$review_scores_Goodrating <- NULL

#obtain distance matrix
d <- dist(listingSampl)

#plot dendodgram
hc <- hclust(d, method="complete")
plot(hc)

#sample set Hierarchical Clustering add data points
# cut tree into 5 clusters
rect.hclust(hc, k=5, border="red")

# cut tree into 3 clusters
rect.hclust(hc, k=3, border="blue")

# cut tree into 7 clusters
rect.hclust(hc, k=7, border="green")

#plot with 5 clusters
groups_5 <- cutree(hc, k=5)
plot(listQ1, col=groups_5)
table()


#plot with 3 clusters
groups_3 <- cutree(hc, k=3)
plot(listQ1, col=groups_3)


#plot with 7 clusters
groups_7 <- cutree(hc, k=7)
plot(listQ1, col=groups_7)

#---------------------------Question 2 -----------------------------------------------#


df <- listingH[ , c("beds", "zipcode_freq", "price")]
head(df)
df <- na.omit(df)
listQ2 <- scale(df) #standardize variables

View(listQ2)
listQ2<- df

#Small sample size
set.seed(123) 
listing_idx <- sample(seq_len(nrow(listQ2)), size=floor(nrow(listQ2)))
subListQ2 <- listQ2[listing_idx,]

idx <- sample(1:dim(subListQ2)[1], 40)
listingSampl <- subListQ2[idx,]
listingSampl$price <- NULL


#obtain distance matrix
d <- dist(listingSampl)

#plot dendodgram
hc <- hclust(d, method="complete")
plot(hc)

#sample set Hierarchical Clustering add data points
# cut tree into 5 clusters
rect.hclust(hc, k=5, border="red")

# cut tree into 3 clusters
rect.hclust(hc, k=3, border="blue")

# cut tree into 7 clusters
rect.hclust(hc, k=7, border="green")

#plot with 5 clusters
groups_5 <- cutree(hc, k=5)
plot(listQ1, col=groups_5)


#plot with 3 clusters
groups_3 <- cutree(hc, k=3)
plot(listQ1, col=groups_3)


#plot with 7 clusters
groups_7 <- cutree(hc, k=7)
plot(listQ1, col=groups_7)


#---------------------------Question 3 -----------------------------------------------#


df <- listingH[ , c("reviews_per_month", "zipcode_freq", "review_scores_location")]
head(df)
df <- na.omit(df)
listQ3 <- scale(df) #standardize variables

View(listQ3)

#Small sample size
set.seed(25) 
listing_idx <- sample(seq_len(nrow(listQ3)), size=floor(nrow(listQ3)))
subListQ3 <- listQ3[listing_idx,]

idx <- sample(1:dim(subListQ3)[1], 40)
listingSampl <- subListQ3[idx,]
listingSampl$review_scores_location <- NULL


#obtain distance matrix
d <- dist(listingSampl)

#plot dendodgram
hc <- hclust(d, method="complete")
plot(hc)

#sample set Hierarchical Clustering add data points
# cut tree into 5 clusters
rect.hclust(hc, k=5, border="red")

# cut tree into 3 clusters
rect.hclust(hc, k=3, border="blue")

# cut tree into 7 clusters
rect.hclust(hc, k=7, border="green")

#plot with 5 clusters
groups_5 <- cutree(hc, k=5)
plot(listQ1, col=groups_5)


#plot with 3 clusters
groups_3 <- cutree(hc, k=3)
plot(listQ1, col=groups_3)


#plot with 7 clusters
groups_7 <- cutree(hc, k=7)
plot(listQ1, col=groups_7)

#---------------------------Question 4 -----------------------------------------------#


df <- listingH[ , c("accommodates", "beds", "zipcode_freq", "reviews_per_month", "dependent")]
head(df)
df <- na.omit(df)
listQ3 <- scale(df) #standardize variables

View(listQ3)

#Small sample size
set.seed(80) 
listing_idx <- sample(seq_len(nrow(listQ3)), size=floor(nrow(listQ3)))
subListQ3 <- listQ3[listing_idx,]

idx <- sample(1:dim(subListQ3)[1], 40)
listingSampl <- subListQ3[idx,]
listingSampl$review_scores_location <- NULL


#obtain distance matrix
d <- dist(listingSampl)

#plot dendodgram
hc <- hclust(d, method="complete")
plot(hc)

#sample set Hierarchical Clustering add data points
# cut tree into 5 clusters
rect.hclust(hc, k=5, border="red")

# cut tree into 3 clusters
rect.hclust(hc, k=3, border="blue")

# cut tree into 7 clusters
rect.hclust(hc, k=7, border="green")

#plot with 5 clusters
groups_5 <- cutree(hc, k=5)
plot(listQ1, col=groups_5)


#plot with 3 clusters
groups_3 <- cutree(hc, k=3)
plot(listQ1, col=groups_3)


#plot with 7 clusters
groups_7 <- cutree(hc, k=7)
plot(listQ1, col=groups_7)

#-------------------------------------- Complete Dataset without sampling-----------------------------#
#Hierarchical Clustering add data points
d <- dist(listQ1, method = "euclidean") # distance matrix

fit <- hclust(d, method = "complete") 
plot(fit, cex=0.9) # display dendogram

clusterCut <- cutree(fit, k=7) # cut tree into 7 clusters

#draw dendogram with red borders around the 7 clusters 
rect.hclust(fit, k=7, border="red")
