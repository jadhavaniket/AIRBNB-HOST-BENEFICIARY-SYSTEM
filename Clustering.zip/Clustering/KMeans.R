#K-means
setwd("/Users/nik/Documents/Nik/MIM/INST737/Project/Clustering/kMeans")
listing <- read.csv("listing_latest.csv", header = TRUE)
str(listing)
summary(listing$review_scores_rating)
listing$review_scores_rating <- as.numeric(listing$review_scores_rating)

#econvert rating to categorical variable
listing$review_scores_Goodrating[listing$review_scores_rating >= 20 & listing$review_scores_rating <= 90 ] <- "bad"
listing$review_scores_Goodrating[listing$review_scores_rating > 90 & listing$review_scores_rating <= 95] <- "med"
listing$review_scores_Goodrating[listing$review_scores_rating > 95 & listing$review_scores_rating <= 100] <- "good"
#end

listing$review_scores_Goodrating <- na.omit(listing$review_scores_Goodrating)


listing<-listing[!(is.na(listing$accommodates) | listing$accommodates==""), ]

listing<-listing[!(is.na(listing$price) | listing$price==""), ]


library(ggplot2)
ggplot(listing, aes(listing$accommodates, listing$price, color = listing$review_scores_Goodrating)) + geom_point() + xlim(0, 30) + ylim(0, 2000)


#----------------------------------------------Question 1------------------------------------#
listingDataQ1 <- listing[, c("accommodates", "price")]

#K-Means Cluster Analysis k=2
set.seed(20)
ratingCluster <- kmeans(listingDataQ1, 3, nstart = 20)
ratingCluster

#Check clustering against actual rating
table(ratingCluster$cluster, listing$review_scores_Goodrating)


ratingCluster$cluster <- as.factor(ratingCluster$cluster)
ggplot(listing, aes(listing$review_scores_rating, listing$price, color = ratingCluster$cluster)) + geom_point()+ xlim(0, 100) + ylim(0, 1000)
  

#size of each cluster
ratingCluster$size

#K-Means Cluster Analysis k=3
set.seed(123)
ratingCluster <- kmeans(listingDataQ1, 3, nstart = 60)
ratingCluster

#Check clustering against actual rating
table(ratingCluster$cluster, listing$review_scores_Goodrating)


ratingCluster$cluster <- as.factor(ratingCluster$cluster)
ggplot(listing, aes(listing$review_scores_rating, listing$price, color = ratingCluster$cluster)) + geom_point()+ xlim(0, 100) + ylim(0, 1000)


# size of each cluster
ratingCluster$size


#K-Means Cluster Analysis k=3
set.seed(70)
ratingCluster <- kmeans(listingDataQ1, 3, nstart = 250)
ratingCluster


#Check clustering against actual rating
table(ratingCluster$cluster, listing$review_scores_Goodrating)


ratingCluster$cluster <- as.factor(ratingCluster$cluster)
ggplot(listing, aes(listing$review_scores_rating, listing$price, color = ratingCluster$cluster)) + geom_point()+ xlim(0, 100) + ylim(0, 1000)


# size of each cluster
ratingCluster$size

###############PAM######################

library(cluster)


pamData <-listing[1:100, c("accommodates", "beds", "review_scores_rating")]

pam.res <- pam(scale(pamData), 4)

#Extract cluster medoids:
pam.res$medoids

#Extract clustering vectors
head(pam.res$cluster)

clusplot(pam.res, main = "Cluster plot, k = 4", color = TRUE)

library("factoextra")
fviz_cluster(pam.res)
